/*:
 ## Exercício – Definição de enums
 
 Pratique a definição de enums. Lembre-se das regras sobre a nomeação de enums e seus casos. 
 
 - callout(Exercise):\
(Exercício):\
Defina uma enum para os sentidos da bússola: Norte, Sul, Leste e Oeste.
*/





//: - callout(Exercise):\
//:(Exercício):\
//:Defina uma enum para as peças de um quebra-cabeça: canto, borda e meio.




//: - callout(Exercise):\
//:(Exercício):\
//:Defina uma enum para os modos de reprodução de um app de música: padrão, repetir, repetir todas e aleatório.
 
 
 



//: [Anterior](@previous)  |  página 17 de 21  |  [Na sequência: Exercício – Contagem de galinhas](@next)
