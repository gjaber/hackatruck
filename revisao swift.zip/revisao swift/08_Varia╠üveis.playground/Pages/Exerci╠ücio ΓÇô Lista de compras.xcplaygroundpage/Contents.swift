/*:
 ## Exercício – Lista de compras

 As constantes abaixo representam alguns itens que podem ser adicionados a uma lista de compras:
*/
let eggs = "Ovos"
let milk = "Leite"
let cheese = "Queijo"
let bread = "Pão"
let rice = "Arroz"
let newLine = "\n"
//: - callout(Exercise):\
//:(Exercício):\
//:Crie uma variável de string com valor inicial de `""`. Adicione os itens de constante à lista acima, um de cada vez. Adicione `newLine` entre os itens. Lembre que você pode combinar duas strings usando o operador `+`.






//: [Anterior](@previous)  |  página 12 de 13  |  [Na sequência: Exercício – 501](@next)
