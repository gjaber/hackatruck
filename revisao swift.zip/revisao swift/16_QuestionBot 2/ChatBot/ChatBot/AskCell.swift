import UIKit

/// Tem um campo de texto para o usuário inserir uma pergunta
class AskCell: UITableViewCell {

    @IBOutlet weak var textField: UITextField!

}
