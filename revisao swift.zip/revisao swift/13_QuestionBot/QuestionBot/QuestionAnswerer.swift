struct MyQuestionAnswerer {
    func responseTo(question: String) -> String {
        // TODO: Escreva uma resposta 
        return "?"
    }
}
