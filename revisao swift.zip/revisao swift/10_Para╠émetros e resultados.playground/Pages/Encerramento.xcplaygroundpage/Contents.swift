/*:
 ## Encerramento
 
 Nesta aula, você aprendeu a potencializar suas funções fazendo com que elas recebam informações, usem essas informações e transmitam outras.
 
 Você aprendeu que as funções devem ser lidas como frases quando são invocadas. Para isso, você precisa escolher com cuidado os nomes dos parâmetros e das funções.
 
 Assim como todos os programas de computação, os apps são formados por muitas funções, que transmitem, recebem e trabalham com as informações. Agora você é capaz de criar essas peças básicas.
 
 Faça os exercícios para praticar o que você aprendeu.
 
[Anterior](@previous)  |  página 13 de 17  |  [Na sequência: Exercício – O verbo e o substantivo](@next)
*/
