/*:
 ## Encerramento
 
 - Tomar decisões e escolher o código a executar com base nelas deixa sua programação mais poderosa.
 - As decisões podem ser tomadas com instruções de comparação, que podem ter os valores `true` ou `false`
 - As instruções de comparação podem ser usadas para executar partes do código, com `if` e `else`
 
 ```
(Exemplo):
 let youWantToPractice = true
 if youWantToPractice {
    Faça os exercícios!
 }
 ```
 
[Anterior](@previous)  |  página 10 de 13  |  [Na sequência: Exercício – Instrução “if” na prática](@next)
*/
