/*:
 ## Meme funcional
 
 Pense em uma música ou um meme que você ouviu ou viu recentemente e que tenha partes repetitivas. Por exemplo:
 
 - Uma música com um refrão que se repete.
 - Um meme que repete uma palavra ou frase.
 - Uma música que repete um verso várias vezes.
 
 Escreva a música ou o meme usando instruções `print`, depois procure padrões e repetições e escolha grupos de linhas para combinar em funções. Este exercício é livre, então você pode fazer o que quiser.
*/


















//: A seguir, deixe o meme do seu jeito.
//:
//: [Anterior](@previous)  |  Página 11 de 12  |  [Na sequência: Meme pessoal](@next)
