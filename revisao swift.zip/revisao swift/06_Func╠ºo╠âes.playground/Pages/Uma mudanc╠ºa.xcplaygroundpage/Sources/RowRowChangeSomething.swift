public func merrilyDream() {
    print("Não cai não, não cai não, não cai não")
    print("Cai na rua do Sabão")
}
public func crocodileScream() {
    print("Não vou lá, não vou lá, não vou lá")
    print("Tenho medo de apanhar")
}
public func repetitiveTheme() {
    print("Essa música é muito repetitiva")
    print("Entendeu a questão?")
}
public func breatheBetweenVerses() {
    print("        ~        ")
}



