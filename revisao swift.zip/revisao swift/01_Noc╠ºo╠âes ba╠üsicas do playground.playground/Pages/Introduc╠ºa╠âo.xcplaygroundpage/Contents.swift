//: ## Noções básicas do playground
//: Bem-vindo ao seu primeiro playground! Neste curso, você vai usar playgrounds para aprender noções básicas de programação. Para começar, vamos fazer um tour e formular alguns códigos.
//:
//: Mas, antes, você consegue ver bolinhas piscando aqui embaixo?
//: Se não estiver conseguindo, selecione Editor > Show Rendered Markup (Editor > Mostrar marcação renderizada) na barra de menus superior.
//:
//: ![bolinhas piscando](swiftloading.gif)
//:
//: Se as bolinhas estiverem piscando, você já pode começar.
//:
//:página 1 de 7  |  [Na sequência: O que é um playground?](@next)
