/*:
 ## Exercício – Lista
 
 Listas são ótimas. Estas constantes descrevem algumas coisas que você já aprendeu sobre strings até agora:
 */
let constants = "Como declarar constantes string"
let unicode = "Caracteres Unicode (😎)"
let combining = "Combinação de strings com +"
let interpolation = "Interpolação de strings (ou Preencha as lacunas)"
let escaping = "Caracteres de escape para \"poderes especiais\""
let newline = "Inserção de novas linhas"
/*:
 - experiment:\
(Experiência):\
Formule uma nova constante string que seja uma lista de coisas que você aprendeu, cada entrada em uma nova linha. Não se esqueça de adicionar o resultado à página do playground para poder ver bem a lista.
 */





//:
//:[Anterior](@previous)  |  página 13 de 16  |  [Na sequência: Exercício – Restaurante](@next)
